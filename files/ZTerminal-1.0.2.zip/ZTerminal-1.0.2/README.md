# ZTerminal
The better terminal.

## What is ZTerminal?
ZTerminal is a terminal application intended to be a 
cross-platform replacement to the default terminal application
on almost all operating systems. With better commands and better syntax,
you'll wish it was the default.

## ZTerminal Shell Scripting Language / ZTSS
ZTSS is a language inspired by Batch and Bash.
It has everything you can do in ZTerminal,
but fully automated where you can perfectly run
scripts without having to type them in
### over, and over, and over again.

### So what are you waiting for?
Download ZTerminal now and get ready to
unleash your computer's greatness.

### Credits
ZTerminal (ZT) is open-source software owned by
Strawberry Milk Software under the MIT license (read more in the LICENSE file).

ChocoEdit, software bundled into ZTerminal was previously
owned by Choco Software, which was acquired by Strawberry Milk Software on
December 26, 2022.
